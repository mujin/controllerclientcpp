var searchData=
[
  ['jobstatus',['JobStatus',['../structmujinclient_1_1JobStatus.html',1,'mujinclient']]]
];
